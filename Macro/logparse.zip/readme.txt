-----------------------
-----------------------

Readme for logparse.zip

-----------------------
-----------------------


This ZIP archive contains the SAS files logparse.sas, passinfo.sas,
and mvsinfo.sas, which are experimental macros for SAS 9.1 and
later releases.

The %LOGPARSE() macro, together with the FULLSTIMER system option,
extracts statistics from the SAS log about the performance of a
specified SAS program.

The %PASSINFO macro is optional. It calls the %MVSNAME macro and
provides session information to the %LOGPARSE() macro.

The %LOGPARSE() macro might be added to the SAS Sample Library in
an upcoming release. Please send comments and questions to:

   bill.brideson@sas.com



---------------------------
Using the %LOGPARSE() Macro
---------------------------

In the following instructions, myprogram.sas is the program whose
performance statistics you want to measure.

1. Save logparse.sas, mvsname.sas, and passinfo.sas to the
appropriate directory on your computer.

2. Specify the FULLSTIMER option in an OPTIONS statement on the first
line of myprogram.sas, or submit it on the command line.

3. To get optional, supplementary information about your SAS
session, add the following code on the second line of
myprogram.sas:

   %passinfo;

4. Create a new SAS program (referred to as logparseprogram.sas in
these instructions) that calls the %LOGPARSE() macro. See the
syntax section below for arguments to %LOGPARSE().

For example, the following code could be contained in a
logparseprogram.sas program that runs in batch under Windows
(details might vary for other operating environments):

   %include logparse;
   %logparse( myprogram.log, myperfdata, OTH );
   proc print data=myperfdata;
   run;

5. Run myprogram.sas and save the log in a file called
myprogram.log.

6. Run logparseprogram.sas to collect and print the performance
statistics.


----------------------
Syntax for %LOGPARSE()
----------------------

   %logparse(saslog, outds, system, pdsloc, append=no)

where:

   saslog  = SAS log file (for MVS, see "pdsloc" below).
   outds   = output data set for results (optional):
             - if not specified, WORK.DATAn is created, where
               n is the smallest integer that makes the name
               unique (same behavior as "data; x = 1; run;").
             - if specified, names the data set created by
               this invocation of %logparse().
             - if specified and append=yes is specified, see
               documentation of the append= parameter, below.
   system  = 3-character operating system code. This parameter
             is optional; the default value is the sysem on
             which %logparse() is run. Valid codes are:
              z/OS, OS/390, or MVS    = MVS
              OpenVMS Alpha           = ALP
              OpenVMS VAX             = VMS
              All other OSs           = OTH
   pdsloc  = When %logparse() is executed on an MVS system and
             the SAS log file to be analyzed is stored in a
             partitioned data set (PDS), "pdsloc" partially
             names the PDS and "saslog" names the member.  The
             PDS name is generated with a leading period (the
             system uses your userid for the first level of the
             name) and the last level is assumed to be LOGS.
             Example:  SAS log is MYACCT.PRJ5.GRP24.LOGS(TEST47)
                       %logparse(test47, , , prj5.grp24);
   append  = create or append to the output data set (see the
             "outds" parameter, above).  This parameter is optional;
             the default value is NO.  Valid values are YES and NO:
             NO  = %logparse() creates a new SAS file according
                   to the rules for the outds parameter, above.
             YES = %logparse() appends its output to the file
                   named by the outds parameter (the file is
                   created if it does not already exist).
             Example:  %logparse(mypgm.log, lpout, VMS, append=yes);


----------
References
----------

For more information about FULLSTIMER, see "Optimizing System
Performance" in SAS Language Reference: Concepts in the SAS online
documentation. See also FULLSTIMER reference information in the
SAS Companion for your operating environment.

More performance ideas can be found in the Scalability and
Performance Community at http://support.sas.com/rnd/scalability


----------
Disclaimer
----------

THIS PRELIMINARY DOCUMENTATION IS PROVIDED "AS IS" WITHOUT WARRANTY
OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE, OR NON-INFRINGEMENT. The Institute shall not be
liable whatsoever for any damages arising out of the use of this
documentation, including any direct, indirect, or consequential
damages. The Institute reserves the right to alter or abandon use of
this documentation at any time. In addition, the Institute will
provide no support for the materials contained herein.


Copyright (c) 2004, SAS Institute Inc., Cary, NC, USA. All rights reserved.

RESTRICTED RIGHTS LEGEND 	
Use, duplication, or disclosure by the U.S. Government is subject to
restrictions as set forth in subparagraph (c)(1)(ii) of the Rights in
Technical Data and Computer Software clause at DFARS 252.227-7013.
SAS INSTITUTE INC., SAS CAMPUS DRIVE, CARY, NORTH CAROLINA USA 27513

